using Microsoft.VisualBasic.ApplicationServices;

namespace Рандомайзер
{
    public partial class Form1 : Form
    {
        public int a, b, R;
        public string r, Hstring, time;
        Random Random = new Random();
        List<string> list = new List<string>();
        DateTime dateTime = DateTime.Now;
        private void историяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form HistoryForm = new Form()
            {
                Size = new System.Drawing.Size(600, 300)
            };
            HistoryForm.Text = "История сгенерированных чисел";
            HistoryForm.MaximizeBox = false;
            HistoryForm.MinimizeBox = false;
            ListBox HistoryBox = new ListBox()
            {
                Size = new Size(600, 300)
            };
            HistoryForm.Controls.Add(HistoryBox);
            HistoryBox.MultiColumn = true;
            HistoryBox.BeginUpdate();
            int n = list.Count();
            for (int i = 0; i < n; i++)
            {
                HistoryBox.Items.Add(list[i]);
            }
            HistoryForm.ShowDialog();
        }

        private void RandomizeButton_Click(object sender, EventArgs e)
        {
            try
            {
                a = Convert.ToInt32(FirstRangePointTextBox.Text);
                b = Convert.ToInt32(SecondRangePointTextBox.Text);
            }
            catch (Exception)
            {

            }
            R = Random.Next(a, b + 1);
            ResultTextBox.Text = R.ToString();
            r = R.ToString();
            time = dateTime.ToString();
            Hstring = $"{time}: От {FirstRangePointTextBox.Text} До {SecondRangePointTextBox.Text} -> {r}";
            list.Add(Hstring);
        }

        public Form1()
        {
            InitializeComponent();
        }
    }
}