﻿using MineSweeper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using MineSweeper.Controls;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MineSweeper
{
    public partial class Form : System.Windows.Forms.Form
    {
        public Form()
        {
            InitializeComponent();
            MapController.Init(this);
        }

        private void Form_Load(object sender, EventArgs e)
        {

        }
    }
}
