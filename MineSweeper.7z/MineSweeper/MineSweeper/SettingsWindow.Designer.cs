﻿namespace MineSweeper
{
    partial class SettingsWindow
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SettingsWindow));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.IntermidiateDifficulty = new System.Windows.Forms.CheckBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.InsaneDifficulty = new System.Windows.Forms.CheckBox();
            this.LaunchButton = new System.Windows.Forms.Button();
            this.BeginnerDifficulty = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.SystemColors.Control;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(90, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(54, 13);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "Lenght";
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Control;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(150, 12);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(54, 13);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "Width";
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.SystemColors.Control;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Location = new System.Drawing.Point(210, 12);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(54, 13);
            this.textBox3.TabIndex = 2;
            this.textBox3.Text = "Mines";
            // 
            // IntermidiateDifficulty
            // 
            this.IntermidiateDifficulty.AutoSize = true;
            this.IntermidiateDifficulty.Location = new System.Drawing.Point(12, 64);
            this.IntermidiateDifficulty.Name = "IntermidiateDifficulty";
            this.IntermidiateDifficulty.Size = new System.Drawing.Size(80, 17);
            this.IntermidiateDifficulty.TabIndex = 4;
            this.IntermidiateDifficulty.Text = "Intermidiate";
            this.IntermidiateDifficulty.UseVisualStyleBackColor = true;
            this.IntermidiateDifficulty.CheckedChanged += new System.EventHandler(this.IntermidiateDifficulty_CheckedChanged);
            // 
            // textBox4
            // 
            this.textBox4.BackColor = System.Drawing.SystemColors.Control;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Location = new System.Drawing.Point(90, 39);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(54, 13);
            this.textBox4.TabIndex = 5;
            this.textBox4.Text = "       9";
            // 
            // textBox5
            // 
            this.textBox5.BackColor = System.Drawing.SystemColors.Control;
            this.textBox5.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox5.Location = new System.Drawing.Point(150, 39);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(54, 13);
            this.textBox5.TabIndex = 6;
            this.textBox5.Text = "       9";
            // 
            // textBox6
            // 
            this.textBox6.BackColor = System.Drawing.SystemColors.Control;
            this.textBox6.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox6.Location = new System.Drawing.Point(210, 39);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(54, 13);
            this.textBox6.TabIndex = 7;
            this.textBox6.Text = "     10";
            // 
            // textBox7
            // 
            this.textBox7.BackColor = System.Drawing.SystemColors.Control;
            this.textBox7.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox7.Location = new System.Drawing.Point(90, 65);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(54, 13);
            this.textBox7.TabIndex = 8;
            this.textBox7.Text = "      16";
            // 
            // textBox8
            // 
            this.textBox8.BackColor = System.Drawing.SystemColors.Control;
            this.textBox8.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox8.Location = new System.Drawing.Point(150, 65);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(54, 13);
            this.textBox8.TabIndex = 9;
            this.textBox8.Text = "      16";
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.Control;
            this.textBox9.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox9.Location = new System.Drawing.Point(210, 65);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(54, 13);
            this.textBox9.TabIndex = 10;
            this.textBox9.Text = "     40";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.Control;
            this.textBox10.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox10.Location = new System.Drawing.Point(90, 91);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(54, 13);
            this.textBox10.TabIndex = 11;
            this.textBox10.Text = "      30";
            // 
            // textBox11
            // 
            this.textBox11.BackColor = System.Drawing.SystemColors.Control;
            this.textBox11.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox11.Location = new System.Drawing.Point(150, 91);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(54, 13);
            this.textBox11.TabIndex = 12;
            this.textBox11.Text = "      30";
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.Control;
            this.textBox12.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox12.Location = new System.Drawing.Point(210, 91);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(54, 13);
            this.textBox12.TabIndex = 13;
            this.textBox12.Text = "    150";
            // 
            // InsaneDifficulty
            // 
            this.InsaneDifficulty.AutoSize = true;
            this.InsaneDifficulty.Location = new System.Drawing.Point(12, 90);
            this.InsaneDifficulty.Name = "InsaneDifficulty";
            this.InsaneDifficulty.Size = new System.Drawing.Size(58, 17);
            this.InsaneDifficulty.TabIndex = 14;
            this.InsaneDifficulty.Text = "Insane";
            this.InsaneDifficulty.UseVisualStyleBackColor = true;
            this.InsaneDifficulty.CheckedChanged += new System.EventHandler(this.InsaneDifficulty_CheckedChanged);
            // 
            // LaunchButton
            // 
            this.LaunchButton.BackColor = System.Drawing.SystemColors.Control;
            this.LaunchButton.Cursor = System.Windows.Forms.Cursors.Default;
            this.LaunchButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.LaunchButton.Location = new System.Drawing.Point(12, 113);
            this.LaunchButton.Name = "LaunchButton";
            this.LaunchButton.Size = new System.Drawing.Size(252, 41);
            this.LaunchButton.TabIndex = 19;
            this.LaunchButton.Text = "Launch";
            this.LaunchButton.UseVisualStyleBackColor = false;
            this.LaunchButton.Click += new System.EventHandler(this.LaunchButton_Click);
            // 
            // BeginnerDifficulty
            // 
            this.BeginnerDifficulty.AutoSize = true;
            this.BeginnerDifficulty.Location = new System.Drawing.Point(12, 39);
            this.BeginnerDifficulty.Name = "BeginnerDifficulty";
            this.BeginnerDifficulty.Size = new System.Drawing.Size(68, 17);
            this.BeginnerDifficulty.TabIndex = 20;
            this.BeginnerDifficulty.Text = "Beginner";
            this.BeginnerDifficulty.UseVisualStyleBackColor = true;
            this.BeginnerDifficulty.CheckedChanged += new System.EventHandler(this.BeginnerDifficulty_CheckedChanged);
            // 
            // SettingsWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(276, 159);
            this.Controls.Add(this.BeginnerDifficulty);
            this.Controls.Add(this.LaunchButton);
            this.Controls.Add(this.InsaneDifficulty);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.IntermidiateDifficulty);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SettingsWindow";
            this.Text = "Settings";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.CheckBox IntermidiateDifficulty;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.CheckBox InsaneDifficulty;
        private System.Windows.Forms.Button LaunchButton;
        private System.Windows.Forms.CheckBox BeginnerDifficulty;
    }
}

