﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//Я немного напутал и в итоге получилось так, что length - это ширина, width - это высота
namespace MineSweeper
{

    public partial class SettingsWindow : System.Windows.Forms.Form
    {
        public static int L, W, M;
        public bool SpecialDif;
        public int Difficulty;
        private void BeginnerDifficulty_CheckedChanged(object sender, EventArgs e)
        {
            if (BeginnerDifficulty.Checked == true)
            {
                InsaneDifficulty.Checked = false;
                IntermidiateDifficulty.Checked = false;
                L = 9;
                W = 9;
                M = 10;
            }
        }

        private void InsaneDifficulty_CheckedChanged(object sender, EventArgs e)
        {
            if (InsaneDifficulty.Checked == true)
            {
                BeginnerDifficulty.Checked = false;
                IntermidiateDifficulty.Checked = false;
                L = 30;
                W = 30;
                M = 150;
            }
        }

        public void LaunchButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form form = new Form();
            form.Closed += (s, args) => this.Close();
            form.Show();
        }

        private void IntermidiateDifficulty_CheckedChanged(object sender, EventArgs e)
        {
            if (IntermidiateDifficulty.Checked == true)
            {
                InsaneDifficulty.Checked = false;
                BeginnerDifficulty.Checked = false;
                L = 16;
                W = 16;
                M = 40;
            }
        }

        public SettingsWindow()
        {
            InitializeComponent();
        }
    }

}


